///-----------------------------------------------------------------
///
/// @file      SaturnTestDlg.cpp
/// @author    
/// Created:   12/1/2013 6:50:40 PM
/// @section   DESCRIPTION
///            SaturnTestDlg class implementation
///
///------------------------------------------------------------------

#include "SaturnTestDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// SaturnTestDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(SaturnTestDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(SaturnTestDlg::OnClose)
	EVT_INIT_DIALOG(SaturnTestDlg::SaturnTestDlgInitDialog)
	EVT_BUTTON(ID_WXBUTTONSTART,SaturnTestDlg::WxButtonStartClick)
END_EVENT_TABLE()
////Event Table End

SaturnTestDlg::SaturnTestDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

SaturnTestDlg::~SaturnTestDlg()
{
} 

void SaturnTestDlg::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxButtonStart = new wxButton(this, ID_WXBUTTONSTART, _("Start Test"), wxPoint(8, 325), wxSize(110, 44), 0, wxDefaultValidator, _("WxButtonStart"));

	WxEditLog = new wxTextCtrl(this, ID_WXEDITLOG, _(""), wxPoint(7, 6), wxSize(548, 315), wxTE_BESTWRAP | wxTE_MULTILINE, wxDefaultValidator, _("WxEditLog"));
	WxEditLog->SetForegroundColour(wxColour(128,0,0));
	WxEditLog->SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_INFOBK));
	WxEditLog->SetFont(wxFont(12, wxSWISS, wxNORMAL, wxNORMAL, false, _("Calibri")));

	SetTitle(_("Saturn FPGA Module Test Application"));
	SetIcon(wxNullIcon);
	SetSize(8,8,573,409);
	Center();
	
	////GUI Items Creation End
}

void SaturnTestDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

void SaturnTestDlg::clearLog()
{
    WxEditLog->Clear();
}

void SaturnTestDlg::addLog(wxString log)
{
    WxEditLog->AppendText(log + wxT("\n"));
}

void SaturnTestDlg::refreshUI()
{
    wxGetApp().Yield();
}

/*
 * WxButtonStartClick
 */
void SaturnTestDlg::WxButtonStartClick(wxCommandEvent& event)
{
    WxButtonStart->Enable(FALSE);
	RunTest(0);
	WxButtonStart->Enable(TRUE);
}




/*
 * SaturnTestDlgInitDialog
 */
void SaturnTestDlg::SaturnTestDlgInitDialog(wxInitDialogEvent& event)
{
	LoadFTLib();
}

//---------------------------------------------------------------------------
//
// Name:        SaturnTestApp.h
// Author:      
// Created:     12/1/2013 6:50:40 PM
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __SATURNTESTDLGApp_h__
#define __SATURNTESTDLGApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class SaturnTestDlgApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif

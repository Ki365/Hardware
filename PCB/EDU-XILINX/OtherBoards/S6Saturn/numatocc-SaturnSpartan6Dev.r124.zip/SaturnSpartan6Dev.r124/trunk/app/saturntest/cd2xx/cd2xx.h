#include <wx/wx.h>
#include "windows.h"
#include "FTD2XX.H"

typedef enum _FT_DEVICE{
    FT_DEVICE_232BM = 0,
    FT_DEVICE_232AM = 1,
    FT_DEVICE_100AX = 2,
    FT_DEVICE_UNKNOWN = 3,
    FT_DEVICE_2232C = 4,
    FT_DEVICE_232R = 5,
    FT_DEVICE_2232H = 6,
    FT_DEVICE_4232H = 7,
    FT_DEVICE_232H = 8,
    FT_DEVICE_X_SERIES = 9
}FT_DEVICE, *PTR_FT_DEVICE;

typedef enum _FT_BIT_MODE{
    FT_RESET = 0x0,
    FT_ASYNC_BIT_BANG = 0x1,
    FT_MPSSE = 0x2,
    FT_SYNC_BIT_BANG = 0x4,
    FT_MCU_HOST_BUS_EMULATION = 0x8,
    FT_FAST_OPTO_ISOLATED_SERIAL = 0x10,
    FT_CBUS_BIT_BANG = 0x20,
    FT_SINGLE_CHANNEL_SYNC_245_FIFO = 0x40
}FT_BIT_MODE, *PTR_FT_BIT_MODE;

typedef struct _ft_device_list_info_node { 
    DWORD Flags;
    DWORD Type;
    DWORD ID; 
    DWORD LocId; 
    char SerialNumber[16]; 
    char Description[64]; 
    FT_HANDLE ftHandle; 
}FT_DEVICE_LIST_INFO_NODE, *PTR_FT_DEVICE_LIST_INFO_NODE;

typedef _stdcall FT_STATUS (*FT_CreateDeviceInfoList_type)(LPDWORD lpdwNumDevs);
typedef _stdcall FT_STATUS (*FT_GetDeviceInfoList_type)(FT_DEVICE_LIST_INFO_NODE *pDest, LPDWORD lpdwNumDevs);
typedef _stdcall FT_STATUS (*FT_GetDeviceInfoDetail_type)(DWORD dwIndex, LPDWORD lpdwFlags, LPDWORD lpdwType, LPDWORD lpdwID, LPDWORD lpdwLocId, PCHAR pcSerialNumber, PCHAR pcDescription, FT_HANDLE *ftHandle);
typedef _stdcall FT_STATUS (*FT_Open_type)(int iDevice, FT_HANDLE *ftHandle);
typedef _stdcall FT_STATUS (*FT_OpenEx_type)(PVOID pvArg1, DWORD dwFlags, FT_HANDLE *ftHandle);
typedef _stdcall FT_STATUS (*FT_Close_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_Read_type)(FT_HANDLE ftHandle, LPVOID lpBuffer, DWORD dwBytesToRead, LPDWORD lpdwBytesReturned);
typedef _stdcall FT_STATUS (*FT_Write_type)(FT_HANDLE ftHandle, LPVOID lpBuffer, DWORD dwBytesToWrite, LPDWORD lpdwBytesWritten);
typedef _stdcall FT_STATUS (*FT_SetBaudRate_type)(FT_HANDLE ftHandle, DWORD dwBaudRate);
typedef _stdcall FT_STATUS (*FT_SetDivisor_type)(FT_HANDLE ftHandle, USHORT usDivisor);
typedef _stdcall FT_STATUS (*FT_SetDataCharacteristics_type)(FT_HANDLE ftHandle, UCHAR uWordLength, UCHAR uStopBits, UCHAR uParity);
typedef _stdcall FT_STATUS (*FT_SetTimeouts_type)(FT_HANDLE ftHandle, DWORD dwReadTimeout, DWORD dwWriteTimeout);
typedef _stdcall FT_STATUS (*FT_SetFlowControl_type)(FT_HANDLE ftHandle, USHORT usFlowControl, UCHAR uXon, UCHAR uXoff);
typedef _stdcall FT_STATUS (*FT_SetDtr_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_ClrDtr_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_SetRts_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_ClrRts_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_GetModemStatus_type)(FT_HANDLE ftHandle, LPDWORD lpdwModemStatus);
typedef _stdcall FT_STATUS (*FT_GetQueueStatus_type)(FT_HANDLE ftHandle, LPDWORD lpdwAmountInRxQueue);
typedef _stdcall FT_STATUS (*FT_GetDeviceInfo_type)(FT_HANDLE ftHandle, FT_DEVICE *pftType, LPDWORD lpdwID, PCHAR pcSerialNumber, PCHAR pcDescription, PVOID pvDummy);
typedef _stdcall FT_STATUS (*FT_GetDriverVersion_type)(FT_HANDLE ftHandle, LPDWORD lpdwDriverVersion);
typedef _stdcall FT_STATUS (*FT_GetLibraryVersion_type)(LPDWORD lpdwDLLVersion);
typedef _stdcall FT_STATUS (*FT_GetComPortNumber_type)(FT_HANDLE ftHandle, LPLONG lplComPortNumber);
typedef _stdcall FT_STATUS (*FT_GetStatus_type)(FT_HANDLE ftHandle, LPDWORD lpdwAmountInRxQueue, LPDWORD lpdwAmountInTxQueue, LPDWORD lpdwEventStatus);
typedef _stdcall FT_STATUS (*FT_SetEventNotification_type)(FT_HANDLE ftHandle, DWORD dwEventMask, PVOID pvArg);
typedef _stdcall FT_STATUS (*FT_SetChars_type)(FT_HANDLE ftHandle, UCHAR uEventCh, UCHAR uEventChEn, UCHAR uErrorCh, UCHAR uErrorChEn);
typedef _stdcall FT_STATUS (*FT_SetBreakOn_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_SetBreakOff_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_Purge_type)(FT_HANDLE ftHandle, DWORD dwMask);
typedef _stdcall FT_STATUS (*FT_ResetDevice_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_ResetPort_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_CyclePort_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_Rescan_type)();
typedef _stdcall FT_STATUS (*FT_Reload_type)(WORD wVID, WORD wPID);
typedef _stdcall FT_STATUS (*FT_SetResetPipeRetryCount_type)(FT_HANDLE ftHandle, DWORD dwCount);
typedef _stdcall FT_STATUS (*FT_StopInTask_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_RestartInTask_type)(FT_HANDLE ftHandle);
typedef _stdcall FT_STATUS (*FT_SetDeadmanTimeout_type)(FT_HANDLE ftHandle, DWORD dwDeadmanTimeout);

typedef _stdcall FT_STATUS (*FT_SetBitmode_type)(FT_HANDLE ftHandle, UCHAR ucMask, UCHAR ucMode);

class cd2xx{

public:
    
   cd2xx();
   ~cd2xx();
   
   virtual void addLog(wxString log);
   unsigned int LoadFTLib();
   FT_STATUS OpenDevice(unsigned int Index);
   FT_STATUS CloseDevice();
   FT_STATUS SetMode(FT_BIT_MODE Mode, unsigned char Mask);
   FT_STATUS WriteByte(unsigned char Byte);
   

protected:
   FT_CreateDeviceInfoList_type FT_CreateDeviceInfoList;
   FT_GetDeviceInfoList_type FT_GetDeviceInfoList;
   FT_GetDeviceInfoDetail_type FT_GetDeviceInfoDetail;
   FT_Open_type FT_Open;
   FT_OpenEx_type FT_OpenEx;
   FT_Close_type FT_Close;
   FT_Read_type FT_Read;
   FT_Write_type FT_Write;
   FT_SetBaudRate_type FT_SetBaudRate;
   FT_SetDivisor_type FT_SetDivisor;
   FT_SetDataCharacteristics_type FT_SetDataCharacteristics;
   FT_SetTimeouts_type FT_SetTimeouts;
   FT_SetFlowControl_type FT_SetFlowControl;
   FT_SetDtr_type FT_SetDtr;
   FT_ClrDtr_type FT_ClrDtr;
   FT_SetRts_type FT_SetRts;
   FT_ClrRts_type FT_ClrRts;
   FT_GetModemStatus_type FT_GetModemStatus;
   FT_GetQueueStatus_type FT_GetQueueStatus;
   FT_GetDeviceInfo_type FT_GetDeviceInfo;
   FT_GetDriverVersion_type FT_GetDriverVersion;
   FT_GetLibraryVersion_type FT_GetLibraryVersion;
   FT_GetComPortNumber_type FT_GetComPortNumber;
   FT_GetStatus_type FT_GetStatus;
   FT_SetEventNotification_type FT_SetEventNotification;
   FT_SetChars_type FT_SetChars;
   FT_SetBreakOn_type FT_SetBreakOn;
   FT_SetBreakOff_type FT_SetBreakOff;
   FT_Purge_type FT_Purge;
   FT_ResetDevice_type FT_ResetDevice;
   FT_ResetPort_type FT_ResetPort;
   FT_CyclePort_type FT_CyclePort;
   FT_Rescan_type FT_Rescan;
   FT_Reload_type FT_Reload;
   FT_SetResetPipeRetryCount_type FT_SetResetPipeRetryCount;
   FT_StopInTask_type FT_StopInTask;
   FT_RestartInTask_type FT_RestartInTask;
   FT_SetDeadmanTimeout_type FT_SetDeadmanTimeout;
   FT_SetBitmode_type FT_SetBitmode;
   
private:
   HMODULE m_hFTLib;
   FT_HANDLE ftHandle;

};

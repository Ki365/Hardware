#include "cd2xx.h"

cd2xx::cd2xx()
{
    m_hFTLib = 0;
    ftHandle = 0;
    
    FT_CreateDeviceInfoList = 0;
    FT_GetDeviceInfoList = 0;
    FT_GetDeviceInfoDetail = 0;
    FT_Open = 0;
    FT_OpenEx = 0;
    FT_Close = 0;
    FT_Read = 0;
    FT_Write = 0;
    FT_SetBaudRate = 0;
    FT_SetDivisor = 0;
    FT_SetDataCharacteristics = 0;
    FT_SetTimeouts = 0;
    FT_SetFlowControl = 0;
    FT_SetDtr = 0;
    FT_ClrDtr = 0;
    FT_SetRts = 0;
    FT_ClrRts = 0;
    FT_GetModemStatus = 0;
    FT_GetQueueStatus = 0;
    FT_GetDeviceInfo = 0;
    FT_GetDriverVersion = 0;
    FT_GetComPortNumber = 0;
    FT_SetEventNotification = 0;
    FT_SetChars = 0;
    FT_SetBreakOn = 0;
    FT_SetBreakOff = 0;
    FT_Purge = 0;
    FT_ResetDevice = 0;
    FT_CyclePort = 0;
    FT_Rescan = 0;
    FT_SetResetPipeRetryCount = 0;
    FT_StopInTask = 0;
    FT_RestartInTask = 0;
    FT_SetDeadmanTimeout = 0;
    FT_SetBitmode = 0;
}

cd2xx::~cd2xx()
{
    if(ftHandle)
    {
        FT_Close(ftHandle);
        ftHandle = 0;
    }
}

void cd2xx::addLog(wxString log)
{
    //Do nothing
}

FT_STATUS cd2xx::WriteByte(unsigned char Byte)
{
    FT_STATUS Status;
    DWORD BytesWritten;
    
    Status = FT_Write(ftHandle, &Byte, 1, &BytesWritten);
    
    if(Status != FT_OK)
    {
        addLog(wxT("Error : Call to FT_Write failed.."));
        return Status;
    }
    
    if(BytesWritten != 1 )
    {
        addLog(wxT("Error : All bytes not written.."));
        return FT_IO_ERROR;
    }
    
    return FT_OK;
}

FT_STATUS cd2xx::SetMode(FT_BIT_MODE Mode, unsigned char Mask)
{
    FT_STATUS Status;
    DWORD BytesWritten = 0;
    
    //Issue a reset 
    Status = FT_SetBitmode(ftHandle, 0, FT_RESET);
    if(Status != FT_OK)
    {
        addLog(wxT("Error : Call to FT_SetBitmode with FT_RESET failed.."));
        return Status;
    }
    
    //Set bit mode 
    Status = FT_SetBitmode(ftHandle, Mask, Mode);
    if(Status != FT_OK)
    {
        addLog(wxT("Error : Call to FT_SetBitmode with MODE failed.."));
        return Status;
    }
    
    return FT_OK;
}

FT_STATUS cd2xx::OpenDevice(unsigned int Index)
{
    DWORD numDevices;
    FT_STATUS Status;
    FT_DEVICE_LIST_INFO_NODE *devInfo;
    wxString s;

    Status = FT_CreateDeviceInfoList(&numDevices);
    if(Status != FT_OK)
    {
        addLog(wxT("Error : Call to FT_CreateDeviceInfoList failed.."));
        return Status;
    }

    if(numDevices < Index + 1)
    {
        addLog(wxT("Error : Specified device index not found.."));
        return FT_DEVICE_NOT_FOUND;
    }
    
    if(numDevices)
    {
        devInfo = (FT_DEVICE_LIST_INFO_NODE*)malloc(sizeof(FT_DEVICE_LIST_INFO_NODE)*numDevices);
        
        Status = FT_GetDeviceInfoList(devInfo,&numDevices);
        if(Status != FT_OK)
        {
            addLog(wxT("Error : Call to FT_GetDeviceInfoList failed.."));
            return Status;
        }

        s.Printf("Description = %s", devInfo[Index].Description);
        addLog(s);
    }
    
    Status = FT_Open(Index, &ftHandle);
    if(Status != FT_OK)
    {
        return Status;
    }
    
    return FT_OK;
}

FT_STATUS cd2xx::CloseDevice()
{
    if(ftHandle)
    {
        FT_Close(ftHandle);
        ftHandle = 0;
    }    
}

unsigned int cd2xx::LoadFTLib()
{
	m_hFTLib = LoadLibrary(L"Ftd2xx.dll");
    	
	if(m_hFTLib == NULL)
	{
		addLog(wxT("Error : Unable to load Ftd2xx.dll.."));
		return ERROR_DLL_NOT_FOUND;
	}


    FT_CreateDeviceInfoList = (FT_CreateDeviceInfoList_type)GetProcAddress(m_hFTLib, "FT_CreateDeviceInfoList");
    
    if(!FT_CreateDeviceInfoList)
    {
		addLog(wxT("Error : Could not get proc address for FT_CreateDeviceInfoList.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetDeviceInfoList = (FT_GetDeviceInfoList_type)GetProcAddress(m_hFTLib, "FT_GetDeviceInfoList");
    
    if(!FT_GetDeviceInfoList)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetDeviceInfoList.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetDeviceInfoDetail = (FT_GetDeviceInfoDetail_type)GetProcAddress(m_hFTLib, "FT_GetDeviceInfoDetail");
    
    if(!FT_GetDeviceInfoDetail)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetDeviceInfoDetail.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_Open = (FT_Open_type)GetProcAddress(m_hFTLib, "FT_Open");
    
    if(!FT_Open)
    {
		addLog(wxT("Error : Could not get proc address for FT_Open.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_OpenEx = (FT_OpenEx_type)GetProcAddress(m_hFTLib, "FT_OpenEx");
    
    if(!FT_OpenEx)
    {
		addLog(wxT("Error : Could not get proc address for FT_OpenEx.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_Close = (FT_Close_type)GetProcAddress(m_hFTLib, "FT_Close");
    
    if(!FT_Close)
    {
		addLog(wxT("Error : Could not get proc address for FT_Close.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_Read = (FT_Read_type)GetProcAddress(m_hFTLib, "FT_Read");
    
    if(!FT_Close)
    {
		addLog(wxT("Error : Could not get proc address for FT_Read.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    

    FT_Write = (FT_Read_type)GetProcAddress(m_hFTLib, "FT_Write");
    
    if(!FT_Write)
    {
		addLog(wxT("Error : Could not get proc address for FT_Write.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetBaudRate = (FT_SetBaudRate_type)GetProcAddress(m_hFTLib, "FT_SetBaudRate");
    
    if(!FT_SetBaudRate)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetBaudRate.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetDivisor = (FT_SetDivisor_type)GetProcAddress(m_hFTLib, "FT_SetDivisor");
    
    if(!FT_SetDivisor)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetDivisor.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetDataCharacteristics = (FT_SetDataCharacteristics_type)GetProcAddress(m_hFTLib, "FT_SetDataCharacteristics");
    
    if(!FT_SetDataCharacteristics)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetDataCharacteristics.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetTimeouts = (FT_SetTimeouts_type)GetProcAddress(m_hFTLib, "FT_SetTimeouts");
    
    if(!FT_SetTimeouts)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetTimeouts.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetFlowControl = (FT_SetFlowControl_type)GetProcAddress(m_hFTLib, "FT_SetFlowControl");
    
    if(!FT_SetFlowControl)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetFlowControl.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetDtr = (FT_SetDtr_type)GetProcAddress(m_hFTLib, "FT_SetDtr");
    
    if(!FT_SetDtr)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetDtr.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_ClrDtr = (FT_ClrDtr_type)GetProcAddress(m_hFTLib, "FT_ClrDtr");
    
    if(!FT_ClrDtr)
    {
		addLog(wxT("Error : Could not get proc address for FT_ClrDtr.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetRts = (FT_SetRts_type)GetProcAddress(m_hFTLib, "FT_SetRts");
    
    if(!FT_SetRts)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetRts.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_ClrRts = (FT_ClrRts_type)GetProcAddress(m_hFTLib, "FT_ClrRts");
    
    if(!FT_ClrRts)
    {
		addLog(wxT("Error : Could not get proc address for FT_ClrRts.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetModemStatus = (FT_GetModemStatus_type)GetProcAddress(m_hFTLib, "FT_GetModemStatus");
    
    if(!FT_GetModemStatus)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetModemStatus.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetQueueStatus = (FT_GetQueueStatus_type)GetProcAddress(m_hFTLib, "FT_GetQueueStatus");
    
    if(!FT_GetQueueStatus)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetQueueStatus.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetDeviceInfo = (FT_GetDeviceInfo_type)GetProcAddress(m_hFTLib, "FT_GetDeviceInfo");
    
    if(!FT_GetDeviceInfo)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetDeviceInfo.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetDriverVersion = (FT_GetDriverVersion_type)GetProcAddress(m_hFTLib, "FT_GetDriverVersion");
    
    if(!FT_GetDriverVersion)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetDriverVersion.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetLibraryVersion = (FT_GetLibraryVersion_type)GetProcAddress(m_hFTLib, "FT_GetLibraryVersion");
    
    if(!FT_GetLibraryVersion)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetLibraryVersion.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
        
    FT_GetComPortNumber = (FT_GetComPortNumber_type)GetProcAddress(m_hFTLib, "FT_GetComPortNumber");
    
    if(!FT_GetComPortNumber)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetComPortNumber.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_GetStatus = (FT_GetStatus_type)GetProcAddress(m_hFTLib, "FT_GetStatus");
    
    if(!FT_GetStatus)
    {
		addLog(wxT("Error : Could not get proc address for FT_GetStatus.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetEventNotification = (FT_SetEventNotification_type)GetProcAddress(m_hFTLib, "FT_SetEventNotification");
    
    if(!FT_SetEventNotification)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetEventNotification.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetChars = (FT_SetChars_type)GetProcAddress(m_hFTLib, "FT_SetChars");
    
    if(!FT_SetChars)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetChars.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetBreakOn = (FT_SetBreakOn_type)GetProcAddress(m_hFTLib, "FT_SetBreakOn");
    
    if(!FT_SetBreakOn)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetBreakOn.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetBreakOff = (FT_SetBreakOff_type)GetProcAddress(m_hFTLib, "FT_SetBreakOff");
    
    if(!FT_SetBreakOff)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetBreakOff.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    
    FT_Purge = (FT_Purge_type)GetProcAddress(m_hFTLib, "FT_Purge");
    
    if(!FT_Purge)
    {
		addLog(wxT("Error : Could not get proc address for FT_Purge.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_ResetDevice = (FT_ResetDevice_type)GetProcAddress(m_hFTLib, "FT_ResetDevice");
    
    if(!FT_ResetDevice)
    {
		addLog(wxT("Error : Could not get proc address for FT_ResetDevice.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_ResetPort = (FT_ResetPort_type)GetProcAddress(m_hFTLib, "FT_ResetPort");
    
    if(!FT_ResetPort)
    {
		addLog(wxT("Error : Could not get proc address for FT_ResetPort.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_CyclePort = (FT_CyclePort_type)GetProcAddress(m_hFTLib, "FT_CyclePort");
    
    if(!FT_CyclePort)
    {
		addLog(wxT("Error : Could not get proc address for FT_CyclePort.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_Rescan = (FT_Rescan_type)GetProcAddress(m_hFTLib, "FT_Rescan");
    
    if(!FT_Rescan)
    {
		addLog(wxT("Error : Could not get proc address for FT_Rescan.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_Reload = (FT_Reload_type)GetProcAddress(m_hFTLib, "FT_Reload");
    
    if(!FT_Reload)
    {
		addLog(wxT("Error : Could not get proc address for FT_Reload.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetResetPipeRetryCount = (FT_SetResetPipeRetryCount_type)GetProcAddress(m_hFTLib, "FT_SetResetPipeRetryCount");
    
    if(!FT_SetResetPipeRetryCount)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetResetPipeRetryCount.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_StopInTask = (FT_StopInTask_type)GetProcAddress(m_hFTLib, "FT_StopInTask");
    
    if(!FT_StopInTask)
    {
		addLog(wxT("Error : Could not get proc address for FT_StopInTask.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_RestartInTask = (FT_RestartInTask_type)GetProcAddress(m_hFTLib, "FT_RestartInTask");
    
    if(!FT_RestartInTask)
    {
		addLog(wxT("Error : Could not get proc address for FT_RestartInTask.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetDeadmanTimeout = (FT_SetDeadmanTimeout_type)GetProcAddress(m_hFTLib, "FT_SetDeadmanTimeout");
    
    if(!FT_SetDeadmanTimeout)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetDeadmanTimeout.."));
		return ERROR_DLL_INIT_FAILED; 
    }
    
    
    FT_SetBitmode = (FT_SetBitmode_type)GetProcAddress(m_hFTLib, "FT_SetBitMode");
    
    if(!FT_SetBitmode)
    {
		addLog(wxT("Error : Could not get proc address for FT_SetBitmode.."));
		return ERROR_DLL_INIT_FAILED; 
    }
}

//---------------------------------------------------------------------------
//
// Name:        SaturnTestApp.cpp
// Author:      
// Created:     12/1/2013 6:50:40 PM
// Description: 
//
//---------------------------------------------------------------------------

#include "SaturnTestApp.h"
#include "SaturnTestDlg.h"

IMPLEMENT_APP(SaturnTestDlgApp)

bool SaturnTestDlgApp::OnInit()
{
	SaturnTestDlg* dialog = new SaturnTestDlg(NULL);
	SetTopWindow(dialog);
	dialog->Show(true);		
	return true;
}
 
int SaturnTestDlgApp::OnExit()
{
	return 0;
}

#include "cd2xx/cd2xx.h"

class SaturnTest : public cd2xx
{

public:
    
   SaturnTest();
   ~SaturnTest();
    
   virtual void clearLog();
   virtual void addLog(wxString log);
   virtual void refreshUI();
   void RunTest(unsigned int Index);
   
};

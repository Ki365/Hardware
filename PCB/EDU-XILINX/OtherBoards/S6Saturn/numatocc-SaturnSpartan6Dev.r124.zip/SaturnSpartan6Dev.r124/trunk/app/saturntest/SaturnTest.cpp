#include "SaturnTest.h"

SaturnTest::SaturnTest()
{

}

SaturnTest::~SaturnTest()
{

}

void SaturnTest::clearLog()
{
    //Do nothing
}

void SaturnTest::addLog(wxString log)
{
    //Do nothing
}

void SaturnTest::refreshUI()
{
    //Do nothing
}

void SaturnTest::RunTest(unsigned int Index)
{
    //Open channel A
    OpenDevice(Index);
    
    //Test ACBUS
    addLog(wxT("Info : Testing ACBUS.."));
    
    //Set the channel to MPSSE mode
    SetMode(FT_MPSSE, 0x0);
    
    //Set all IOs to low
    WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	
	//Test ACBUS:0
	addLog(wxT("\nInfo : Setting ACBUS:0 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x01);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:0 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:1
	addLog(wxT("\nInfo : Setting ACBUS:1 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x02);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:1 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:2
	addLog(wxT("\nInfo : Setting ACBUS:2 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x04);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:2 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:3
	addLog(wxT("\nInfo : Setting ACBUS:3 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x08);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:3 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:4
	addLog(wxT("\nInfo : Setting ACBUS:4 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x10);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:4 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:5
	addLog(wxT("\nInfo : Setting ACBUS:5 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x20);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:5 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:6
	addLog(wxT("\nInfo : Setting ACBUS:6 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x40);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:6 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test ACBUS:7
	addLog(wxT("\nInfo : Setting ACBUS:7 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x80);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting ACBUS:7 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);

    //Close device
	CloseDevice();
	
	
	
	//Open channel B
    OpenDevice(Index + 1);
    
    //Test BCBUS
    addLog(wxT("\n\nInfo : Testing BCBUS.."));
    
    //Set the channel to MPSSE mode
    SetMode(FT_MPSSE, 0x0);
    
    //Set all IOs to low
    WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	
	//Test BCBUS:0
	addLog(wxT("\nInfo : Setting BCBUS:0 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x01);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting BCBUS:0 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test BCBUS:1
	addLog(wxT("\nInfo : Setting BCBUS:1 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x02);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting BCBUS:1 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test BCBUS:2
	addLog(wxT("\nInfo : Setting BCBUS:2 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x04);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting BCBUS:2 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test BCBUS:3
	addLog(wxT("\nInfo : Setting BCBUS:3 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x08);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting BCBUS:3 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
	//Test BCBUS:4
	addLog(wxT("\nInfo : Setting BCBUS:4 HIGH.."));
	WriteByte(0x82);
	WriteByte(0x10);
	WriteByte(0xff);
	wxSleep(1);
	addLog(wxT("Info : Setting BCBUS:4 LOW.."));
	WriteByte(0x82);
	WriteByte(0x00);
	WriteByte(0xff);
	wxSleep(1);
	
 
    //Test BDBUS
    addLog(wxT("\n\nInfo : Testing BDBUS.."));
    
    //Set bit bang mode
    SetMode(FT_ASYNC_BIT_BANG, 0xFF);

    //Set all IOs to low
    WriteByte(0x00);
    
 	//Test BCBUS:0
	addLog(wxT("\nInfo : Setting BDBUS:0 HIGH.."));
	WriteByte(0x01);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:0 LOW.."));
	WriteByte(0x00);
	wxSleep(1);   
	
	//Test BCBUS:1
	addLog(wxT("\nInfo : Setting BDBUS:1 HIGH.."));
	WriteByte(0x02);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:1 LOW.."));
	WriteByte(0x00);
	wxSleep(1);
    
    //Test BCBUS:2
	addLog(wxT("\nInfo : Setting BDBUS:2 HIGH.."));
	WriteByte(0x04);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:2 LOW.."));
	WriteByte(0x00);
	wxSleep(1);  
	
	//Test BCBUS:3
	addLog(wxT("\nInfo : Setting BDBUS:3 HIGH.."));
	WriteByte(0x08);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:3 LOW.."));
	WriteByte(0x00);
	wxSleep(1); 
	
	//Test BCBUS:4
	addLog(wxT("\nInfo : Setting BDBUS:4 HIGH.."));
	WriteByte(0x10);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:4 LOW.."));
	WriteByte(0x00);
	wxSleep(1); 
	
	//Test BCBUS:5
	addLog(wxT("\nInfo : Setting BDBUS:5 HIGH.."));
	WriteByte(0x20);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:5 LOW.."));
	WriteByte(0x00);
	wxSleep(1); 
	
	//Test BCBUS:6
	addLog(wxT("\nInfo : Setting BDBUS:6 HIGH.."));
	WriteByte(0x40);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:6 LOW.."));
	WriteByte(0x00);
	wxSleep(1); 
	
	//Test BCBUS:7
	addLog(wxT("\nInfo : Setting BDBUS:7 HIGH.."));
	WriteByte(0x80);
	wxSleep(1);
	addLog(wxT("Info : Setting BDBUS:7 LOW.."));
	WriteByte(0x00);
	wxSleep(1); 
    
    //Close device
	CloseDevice();
	
	addLog(wxT("Info : Test finished.."));
}
